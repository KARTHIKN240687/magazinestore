﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using MagazinePropertyClass;

namespace MagazineBusinessClass
{
    public class GetToken
    {
        public string GetTokenValue()
        {
            HttpClient client = new HttpClient();
            var responseTask = client.GetAsync("http://magazinestore.azurewebsites.net/api/token");
            responseTask.Wait();
            if (responseTask.IsCompleted)
            {
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var message = result.Content.ReadAsStringAsync();
                    message.Wait();
                    var myDetails = JsonConvert.DeserializeObject<GetToken>(message.Result);
                    Console.WriteLine(myDetails.token);
                }
            }

        }
    }
}
