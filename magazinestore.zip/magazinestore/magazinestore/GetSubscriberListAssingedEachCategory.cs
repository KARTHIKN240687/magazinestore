﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace magazinestore
{
    class GetSubscriberListAssingedEachCategory
    {
        #region GetSubcriberListEachCategory
        public static List<string> GetSubcriberListEachCategory(DataTable SubscriberMagzineList, Dictionary<int, string> MagazineListCategory,int MagazineCategoryCount)
        {
            string SubscriberID = string.Empty;
            List<string> SubscriberListAnswer = new List<string>();
            List<string> SubscriberUniqueList = new List<string>();
            //List<string> FinalSubsCriberID = new List<string>();
            // Add SubscriberID and Magazine name to a data table
            DataTable SubscriberMagazineMapping = new DataTable();
            SubscriberMagazineMapping.Columns.Add("SubscriberID");
            SubscriberMagazineMapping.Columns.Add("MagazineName");
            DataRow dr = null;
            foreach (DataRow row in SubscriberMagzineList.Rows)
            {
                SubscriberID = row["SubscriberID"].ToString();
                int MagazineID = int.Parse(row["MagazineID"].ToString());
                // Add Unique Subscribers ID to a list
                if (!SubscriberUniqueList.Contains(SubscriberID))
                {
                    SubscriberUniqueList.Add(SubscriberID);
                }
                // Add SubcriberID, and MagazineName Mapping
                foreach (var item in MagazineListCategory)
                {
                    if (item.Key == MagazineID)
                    {
                        dr = SubscriberMagazineMapping.NewRow(); // have new row on each iteration
                        dr["SubscriberID"] = SubscriberID;
                        dr["MagazineName"] = item.Value;
                        SubscriberMagazineMapping.Rows.Add(dr);
                    }
                }
            }
            // Linq query to find the list of Magazine category for each subscribers
            foreach (var SubscribeID in SubscriberUniqueList)
            {
                DataTable selectedTable = SubscriberMagazineMapping.AsEnumerable()
                            .Where(r => r.Field<string>("SubscriberID") == SubscribeID)
                            .CopyToDataTable();
                List<string> finalMagazineName = new List<string>();
                int count = 0;
                foreach (DataRow row in selectedTable.Rows)
                {
                    if (count == 0)
                    {
                        finalMagazineName.Add(row["MagazineName"].ToString());
                    }
                    else if (!finalMagazineName.Contains(row["MagazineName"].ToString()))
                    {
                        finalMagazineName.Add(row["MagazineName"].ToString());
                    }
                    count++;
                }
                if (finalMagazineName.Count == MagazineCategoryCount)
                {
                    SubscriberListAnswer.Add(SubscribeID);
                }
            }
            return SubscriberListAnswer;
        }
        #endregion
    }
}
