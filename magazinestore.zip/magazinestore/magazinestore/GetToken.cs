﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
namespace magazinestore
{
    class GetToken
    {
        #region GetTokenValue
        public static List<string> GetTokenValue()
        {
            List<string> APIToken = new List<string>();
            APIToken = CommonClass.GetResponseFromAPI(String.Concat(CommonConst.APIURL, CommonConst.Token), "");
            return APIToken;
        }
        #endregion
    }
}
