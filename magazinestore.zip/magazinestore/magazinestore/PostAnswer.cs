﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Data;
using System.IO;
namespace magazinestore
{
    class PostAnswer
    {
        #region PostFinalAnswer
        public static void PostFinalAnswer(List<string> SubscriberID,string TokenValue)
        {
            string APIToken = string.Empty;
            var subscribers = new { subscribers = SubscriberID };
            Console.WriteLine("FinalJSONResult");
            Console.WriteLine(JsonConvert.SerializeObject(subscribers));
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(String.Concat(CommonConst.APIURL, CommonConst.answer, TokenValue));
            httpWebRequest.ContentType = "application/json; charset=utf-8";
            httpWebRequest.Method = "POST";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = JsonConvert.SerializeObject(subscribers);
                streamWriter.Write(json);
                streamWriter.Flush();
                streamWriter.Close();
            }
            Console.WriteLine("Post to Answer API");
            try
            {
                using (var response = httpWebRequest.GetResponse() as HttpWebResponse)
                {
                    if (httpWebRequest.HaveResponse && response != null)
                    {
                        using (var reader = new StreamReader(response.GetResponseStream()))
                        {
                            string result = string.Empty;
                            result = reader.ReadToEnd();
                            Console.WriteLine(result);
                            Console.ReadKey();
                            Console.WriteLine("Response Received");
                        }
                    }
                }
            }
            catch (WebException e)
            {
                Console.WriteLine(e.InnerException);
            }
        }
        #endregion
    }
}
