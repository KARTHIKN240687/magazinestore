﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
namespace magazinestore
{
    class GetMagazineByCategory
    {
        #region GetMagazineForCategory
        public static List<string> GetMagazineForCategory(string TokenValue,string MagazineName)
        {
            List<string> MagazineID = new List<string>();
            MagazineID = CommonClass.GetResponseFromAPI(String.Concat(CommonConst.APIURL, CommonConst.magazines,TokenValue, "/", MagazineName), CommonConst.magazines);
            return MagazineID;
        }
        #endregion
    }
}
