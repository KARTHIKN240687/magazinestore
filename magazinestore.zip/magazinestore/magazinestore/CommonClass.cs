﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
namespace magazinestore
{
    class CommonClass
    {
        #region GetResponseFromAPI
        public static List<string> GetResponseFromAPI(string URL, string APIName)
        {
            List<string> ResultSet = new List<string>();
            HttpClient client = new HttpClient();
            var responseTask = client.GetAsync(URL);
            responseTask.Wait();
            if (responseTask.IsCompleted)
            {
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var message = result.Content.ReadAsStringAsync();
                    message.Wait();

                    #region GetMagazineCategories
                    if (APIName.Contains("Categories"))
                    {
                        var ResponseValue = JsonConvert.DeserializeObject<CategoryDetails>(message.Result);
                        foreach (var item in ResponseValue.data)
                        {
                            ResultSet.Add($"{item}");
                        }
                    }
                    #endregion

                    #region GetMagazineUnderEachCategory
                    else if (APIName.Contains("magazines"))
                    {
                        var ResponseValue = JsonConvert.DeserializeObject<MagazineDetailsList>(message.Result);
                        foreach (var item in ResponseValue.data)
                        {
                            ResultSet.Add(item.id);
                        }
                    }
                    #endregion

                    #region GetToken
                    else
                    {
                        var ResponseValue = JsonConvert.DeserializeObject<TokenDetails>(message.Result);
                        ResultSet.Add(ResponseValue.token);
                    }
                    #endregion
                }
            }
           return ResultSet;
        }
        #endregion

        #region PropertyDeclaration
        public class TokenDetails
        {
            public string success
            {
                get;
                set;
            }
            public string token
            {
                get;
                set;
            }
        }
        public class CategoryDetails
        {
            public string[] data
            {
                get;
                set;
            }
            public string success
            {
                get;
                set;
            }
            public string token
            {
                get;
                set;
            }
        }
        public class MagazineDetailsList
        {
            public List<MagazineDetails> data
            {
                get;
                set;
            }
            public string success
            {
                get;
                set;
            }
            public string token
            {
                get;
                set;
            }
        }
        public class MagazineDetails
        {
            public string id
            {
                get;
                set;
            }
            public string name
            {
                get;
                set;
            }
            public string category
            {
                get;
                set;
            }
        }
        #endregion
    }
}
