﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Data;
using System.IO;
namespace magazinestore
{
    class MagazineMainClass
    {
        # region Variables Declaration
        public static string TokenValue = string.Empty;
        public static List<string> TokenValueList = new List<string>();
        public static List<string> MagazineCategories = new List<string>();
        public static List<string> MagazineID = new List<string>();

        #endregion

        public static void Main(string[] args)
        {
            #region Variables Declaration
            string MagazineName = string.Empty;
            DataTable SubScriberList = new DataTable();
            Dictionary<int, string> MagazineListCategory = new Dictionary<int, string>();
            List<string> FinalSubsCriberID = new List<string>();
            #endregion
            // Get Token Value
            #region GetToken
            TokenValueList = GetToken.GetTokenValue();
            TokenValue = TokenValueList[0];
            Console.WriteLine("TokenIDReceived");
            #endregion
            // Get List of Magazine Categories
            #region MagazineCategories
            MagazineCategories = GetMagazineCategories.GetMagazineCategoriesValues(TokenValue);
            Console.WriteLine("Received all Magazine Categories");
            #endregion
            // Get List of Magazines under each category Categories
            #region GetMagazineListForEachCategory
            foreach (var item in MagazineCategories)
            {
                MagazineName = string.Empty;
                MagazineName = item.ToString();
                MagazineID = GetMagazineByCategory.GetMagazineForCategory(TokenValue, MagazineName);
                foreach (var Magazineitem in MagazineID)
                {
                    MagazineListCategory.Add(int.Parse(Magazineitem), MagazineName);
                }
            }
            Console.WriteLine("Received All Magazines by each category");
            #endregion
            // Get List Of Subscribers
            #region GetSubscriberList
            // GetSubscribers List
            SubScriberList = GetSubscribers.GetSubribersList(TokenValue);
            Console.WriteLine("Received all Subscribers");
            #endregion
            // Get List of Subscirbers Assigned to Atleast one category 
            #region GetSubscriberAssignedAtleastToOneCategory
            FinalSubsCriberID = GetSubscriberListAssingedEachCategory.GetSubcriberListEachCategory(SubScriberList, MagazineListCategory, MagazineCategories.Count);
            Console.WriteLine("Subcribers ID found who is subscribed to atleast one magazine in each category");
            #endregion
            // Post to Answers API
            #region PostAnswerToAPI
            PostAnswer.PostFinalAnswer(FinalSubsCriberID, TokenValue);
            Console.WriteLine("AnswerSuccessfully Posted");
            #endregion
        }
    }
}
