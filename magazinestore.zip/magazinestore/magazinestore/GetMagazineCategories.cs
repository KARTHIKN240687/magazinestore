﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
namespace magazinestore
{
    class GetMagazineCategories
    {
        #region GetMagazineCategoriesValues
        public static List<string> GetMagazineCategoriesValues(string TokenValue)
        {
            List<string> Categories = new List<string>();
            Categories = CommonClass.GetResponseFromAPI(String.Concat(CommonConst.APIURL, CommonConst.Categories, TokenValue), CommonConst.Categories);
            return Categories;
        }
        #endregion
    }
}
