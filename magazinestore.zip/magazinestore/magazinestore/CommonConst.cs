﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace magazinestore
{
    class CommonConst
    {
        public static string APIURL = "http://magazinestore.azurewebsites.net/api/";
        public static string Token = "token";
        public static string Categories = "Categories/";
        public static string magazines = "magazines/";
        public static string Subscribers = "Subscribers/";
        public static string answer = "answer/";
    }
}
