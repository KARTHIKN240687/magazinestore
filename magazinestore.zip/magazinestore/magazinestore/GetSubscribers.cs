﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Data;
namespace magazinestore
{
    class GetSubscribers
    {
        #region GetSubribersList
        public static DataTable GetSubribersList(string TokenValue)
        {
            DataTable SubscriberMagazineDetails = new DataTable();
            HttpClient client = new HttpClient();
            var responseTask = client.GetAsync(String.Concat(CommonConst.APIURL, CommonConst.Subscribers, TokenValue));
            responseTask.Wait();
            if (responseTask.IsCompleted)
            {
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var message = result.Content.ReadAsStringAsync();
                    message.Wait();
                    var ResponseValue = JsonConvert.DeserializeObject<SubscribersDetailsList>(message.Result);
                    SubscriberMagazineDetails.Columns.Add("SubscriberID");
                    SubscriberMagazineDetails.Columns.Add("MagazineID");
                    DataRow dr = null;
                    foreach (var SubscriberID in ResponseValue.data)
                    {
                        foreach (var MagazineID in SubscriberID.magazineIds)
                        {
                            dr = SubscriberMagazineDetails.NewRow();
                            dr["SubscriberID"] = SubscriberID.id;
                            dr["MagazineID"] = int.Parse(MagazineID);
                            SubscriberMagazineDetails.Rows.Add(dr);
                        }
                    }
                }
            }
            return SubscriberMagazineDetails;
        }
        #endregion

        #region PropertyDeclaration
        public class SubscribersDetailsList
        {
            public List<SubcriberDetails> data
            {
                get;
                set;
            }
            public string success
            {
                get;
                set;
            }
            public string token
            {
                get;
                set;
            }
        }
        public class SubcriberDetails
        {
            public string id
            {
                get;
                set;
            }
            public string firstName
            {
                get;
                set;
            }
            public string lastName
            {
                get;
                set;
            }
            public string[] magazineIds
            {
                get;
                set;
            }
        }
        #endregion
    }
}
